from cambio import change

def test_cambio1():
    assert change('a',5) == 'f'
